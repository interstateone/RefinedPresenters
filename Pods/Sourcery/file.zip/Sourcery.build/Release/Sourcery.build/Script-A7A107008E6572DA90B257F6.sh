#!/bin/sh
"${SRCROOT}/Pods/Target Support Files/Pods-Sourcery/Pods-Sourcery-resources.sh"

