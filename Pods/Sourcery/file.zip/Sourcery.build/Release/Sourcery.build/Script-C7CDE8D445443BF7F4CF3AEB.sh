#!/bin/sh
"${SRCROOT}/Pods/Target Support Files/Pods-Sourcery/Pods-Sourcery-frameworks.sh"

